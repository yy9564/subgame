This Asset pack contains a Low Poly printer model. Can be used in an office or an electronics store.

Textures are in .PSD(diffuse, specular) and .PNG  file format (normal), resolution are 1024 x 1024.

I hope you enjoy using the model. Questions and suggestions are welcome.

They are all configured correctly for use with unity, just import into your project.
